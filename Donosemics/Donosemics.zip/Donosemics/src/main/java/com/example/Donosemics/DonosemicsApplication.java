package com.example.Donosemics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonosemicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonosemicsApplication.class, args);
	}

}
