package com.example.Donosemics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonosemicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
