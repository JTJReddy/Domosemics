package com.example.domosemics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomosemicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
